const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware for parsing JSON in the request body
app.use(express.json());

// Serve static files from the public directory
app.use(express.static('public'));

// Function to log activities with timestamps
function logData(activity) {
  const timestamp = new Date().toISOString();
  const logMessage = `${timestamp}: ${activity}\n`;
  fs.appendFileSync('logs.txt', logMessage);
}

// POST endpoint to register new devices
app.post('/register', (req, res) => {
  const { deviceId, deviceType } = req.body;

  // Validate presence of deviceId and deviceType
  if (!deviceId || !deviceType) {
    return res.status(400).json({ error: 'deviceId and deviceType are required' });
  }

  // Load existing devices from devices.json (Bonus)
  const devices = loadDevices();

  // Check if deviceId is already registered
  if (devices.find((device) => device.deviceId === deviceId)) {
    return res.status(409).json({ error: 'Device already registered' });
  }

  // Save new device to devices.json
  devices.push({ deviceId, deviceType });
  fs.writeFileSync('devices.json', JSON.stringify(devices, null, 2));

  // Log registration activity
  logData(`Device registered - ID: ${deviceId}, Type: ${deviceType}`);

  // Respond with status code 201 for successful registration
  res.status(201).json({ message: 'Device registered successfully' });
});

// GET endpoint to display all registered devices
app.get('/show', (req, res) => {
  try {
    // Read devices from devices.json
    const devices = loadDevices();
    res.json(devices);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST endpoint to receive data from devices
app.post('/data', (req, res) => {
  const { deviceId, data } = req.body;
  console.log(req.body);

  // Validate presence of deviceId and data
  if (!deviceId || !data) {
    return res.status(400).json({ success: false, error: 'deviceId and data are required' });
  }

  // Update devices.json with new data
  updateDevices(deviceId, data);

  // Log received data with timestamp
  logData(`Received data from device - ID: ${deviceId}, Data: ${data}`);

  // Respond with a confirmation message
  res.json({ success: true, message: 'Data received successfully' });
});

function updateDevices(deviceId, newData) {
  console.log(deviceId);
  console.log(newData);
  const devicesPath = 'devices.json';

  // Read devices.json file
  fs.readFile(devicesPath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading devices.json:', err);
      return;
    }

    try {
      // Parse JSON data
      const devices = JSON.parse(data);

      // Find the device in the array and update its data
      const updatedDevices = devices.map(device => {
        if (device.deviceId === deviceId) {
          device.data = newData;
        }
        return device;
      });

      // Write the updated data back to devices.json
      fs.writeFile(devicesPath, JSON.stringify(updatedDevices, null, 2), 'utf8', err => {
        if (err) {
          console.error('Error writing to devices.json:', err);
        } else {
          console.log('devices.json updated successfully');
        }
      });
    } catch (parseError) {
      console.error('Error parsing devices.json:', parseError);
    }
  });
}

// POST endpoint to send commands to devices
app.post('/command', (req, res) => {
  const { deviceId, command } = req.body;
  console.log(deviceId)
  console.log(command)

  // Validate presence of deviceId and command
  if (!deviceId || !command) {
    return res.status(400).json({ success: false, error: 'deviceId and command are required' });
  }

  // Update commands.json with new command
  updateCommands(deviceId, command);

  // Log received command with timestamp
  logData(`Received command from device - ID: ${deviceId}, Command: ${command}`);

  // Respond with a confirmation message
  res.json({ success: true, message: 'Command received successfully' });
});

function updateCommands(deviceId, newCommand) {
  console.log(deviceId);
  console.log(newCommand);
  const commandsPath = 'devices.json';

  // Read commands.json file
  fs.readFile(commandsPath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading commands.json:', err);
      return;
    }

    try {
      // Parse JSON data
      const commands = JSON.parse(data);

      // Find the device in the array and update its command
      const updatedCommands = commands.map(device => {
        if (device.deviceId === deviceId) {
          device.command = newCommand;
        }
        return device;
      });

      // Write the updated data back to commands.json
      fs.writeFile(commandsPath, JSON.stringify(updatedCommands, null, 2), 'utf8', err => {
        if (err) {
          console.error('Error writing to commands.json:', err);
        } else {
          console.log('commands.json updated successfully');
        }
      });
    } catch (parseError) {
      console.error('Error parsing commands.json:', parseError);
    }
  });
}


// Function to load existing devices from devices.json 
function loadDevices() {
  try {
    const devicesData = fs.readFileSync('devices.json');
    return JSON.parse(devicesData);
  } catch (error) {
    return [];
  }
}

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

